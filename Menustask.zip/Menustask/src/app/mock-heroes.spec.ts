import { MockHeroes } from './mock-heroes';

describe('MockHeroes', () => {
  it('should create an instance', () => {
    expect(new MockHeroes()).toBeTruthy();
  });
});
