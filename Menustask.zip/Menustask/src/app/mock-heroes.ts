export class MockHeroes {
}
