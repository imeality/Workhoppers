const express=require('express');
const bodyParser = require('body-parser');
var config=require('./config');
var cors = require('cors')
const app=express();
const port=2000;
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: false }));
    app.use(cors());

    app.post('/post/data',function(req,res,next)
{
  var index=config.query("select indexs from Link",function(err,results){
      if(err){console.log(err)}
      else{
      console.log(results[3].indexs);}
       for(var i=0;i<results.length;i++)
       {
            console.log(results[i]);
            console.log(i);
       }

  });

    console.log(req.body);
    var user={
              "url_link" :req.body.url_link,
              "link_text" :req.body.link_text
             }
    console.log(user);
    var Dat='insert into Link set ?';
    config.query(Dat,req.body,function(err,results)
{
    if(err)
{
    console.log("err");
}
    else
{
    console.log(results);
    res.send("insert");
 }
});
});

     app.get('/show',function(req,res)
{
     var Data="select * from Link";
     config.query(Data,function(err,results)
 {
     if(err)
{
     console.log(err);
}
     else
{
     console.log(results);
     res.send(results);
}
});
});
     app.post('/drag/data',function(req,res)
{
      var ind=req.body.currentIndex;
      var indexs=req.body.previousIndex;
     let data = [ind,indexs];
     console.log(data);

                  var Data='UPDATE Link SET indexs=? WHERE id=?';
                   config.query(Data,[indexs,ind],function(err,results){
                         if(err)
                         {
                           console.log(err);
                         }
                         else{console.log(results);
                         }
                   });
                   res.send("Update");
               });
     app.get('/file',function(req,res){
     var element= {"Name":req.body.Name}
     console.log(element);

     res.send("file")
});
     app.listen(port);
     console.log(port);
