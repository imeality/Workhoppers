export class Hero {
}
